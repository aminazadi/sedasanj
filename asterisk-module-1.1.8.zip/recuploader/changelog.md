# Changelog

## 1.1.8 — AMINAZADI

- Added a read-only FreePBX CDR poller that groups linked CDR rows and sends metadata-only missed-call dispositions.
- Added durable cursor, overlap scanning, retry spool, idempotent delivery, and admin controls with CDR readiness guidance.
- Added backward-compatible missed-call settings to imported module profiles.

## 1.1.7 — AMINAZADI

- Added read-only CDR lookup for unambiguous inbound answered-extension attribution.
- Kept the extension unset when CDR evidence is missing or ambiguous.
- Prevented metadata sidecars from being consumed or migrated as JSON queue jobs.

## 1.1.6 — AMINAZADI

- Excluded metadata sidecars from sweeper audio candidates.
- Reported empty WAV recordings before invoking the GSM encoder, while preserving the source for diagnosis.

## 1.1.5 — AMINAZADI

- Fixed import rollback caused by regular-expression backslashes under `INI_SCANNER_RAW`.
- Added Base64-safe storage for endpoints, paths, secrets, and regular-expression settings.
- Changed parse-back validation to load the generated file through the production configuration codec.
- Added deployed-engine checksum verification to prevent an old runtime from restarting after upgrade.

## 1.1.4 — AMINAZADI

- Replaced modern SQLite UPSERT syntax with transactions compatible with older FreePBX SQLite libraries.
- Fixed uploads stopping immediately after the `Starting upload` log entry.
- Added destination and direction recovery for existing inbound recording sidecars.
- Added `CDR(dst)` and `FROM_DID` capture for future inbound recordings.

## 1.1.3 — AMINAZADI

- Fixed missing GSM encoder executable permissions in the FreePBX lifecycle installation path.
- Added import-time permission repair and deployed-runtime GSM encoder validation.

## 1.1.2 — AMINAZADI

- Added fail-safe migration for an already-patched FreePBX core when a verified legacy rollback backup exists.
- Kept unknown, partial, or mismatched core states fail-closed before installation mutation.

## 1.1.1 — AMINAZADI

- Added mandatory, verified pre-installation backups for CLI and FreePBX lifecycle installs.
- Added a checksum-verified restore helper with a fixed managed-path allowlist.
- Documented manual backup, verification, and rollback procedures.

## 1.1.0 — AMINAZADI

- Added versioned JSON import with masked preview, online validation, atomic apply, and rollback.
- Added explicit GZIP, ZIP, and AES-256 ZIP transports with backward-compatible defaults.
- Added durable credit blocking, collision-safe queue identifiers, metadata sidecars, dead-letter manifests, and uploaded-only retention.
- Added PHP 7.4 polyfills, dependency checks, secret-safe configuration encoding, queue status visibility, and pinned binary release verification.
