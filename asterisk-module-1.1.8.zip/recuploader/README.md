# Seda Sanj FreePBX Module 1.1.8

## Missed-call CDR import

The background service can import metadata-only unsuccessful calls from the configured FreePBX CDR database. It groups CDR rows by `linkedid`, suppresses a group if any row is `ANSWERED`, and classifies the final root CDR (or latest available row) as `no_answer`, `busy`, `congestion`, `failed`, or `canceled`. The stable `linkedid` is sent as the Sedasanj unique ID with an idempotency key. No recording, transcript, analysis job, or credit reservation is created for these events.

The poller uses FreePBX's CDR database handle in read-only queries. It requires the CDR backend to write to the configured FreePBX CDR table, including `linkedid`, `uniqueid`, `calldate`, `duration`, `disposition`, `src`, `dst`, and `dcontext`. It waits for a settling period, scans with an overlap window, persists a cursor, and keeps network failures in a durable retry spool. Settings are managed in Admin > Seda Sanj > Missed Calls. Profiles that predate this feature default to enabled with a 30 second poll interval.

The module reports whether the CDR database/table is readable and inspects applicable values in `/etc/asterisk/cdr.conf` `[general]`. Asterisk's `unanswered` option may default to disabled, and `congestion` controls whether a distinct congestion disposition is retained. Confirm the effective configuration for the installed Asterisk version and backend using the official [CDR module configuration reference](https://docs.asterisk.org/Asterisk_22_Documentation/API_Documentation/Module_Configuration/cdr/). The module does not modify global Asterisk configuration. CDR retention must exceed the maximum period during which the poller may be stopped; otherwise records removed before polling cannot be recovered.

Inbound answered-extension attribution reads the completed FreePBX CDR by the recording's exact Asterisk unique ID. Only one unambiguous answered PJSIP/SIP numeric peer is sent as `agent_extension`; otherwise the field stays empty. The CDR may take several seconds to finalize, so the post-processing hook retries briefly. Existing calls already uploaded before this release are not modified.

Supported environments: FreePBX 16/17, PHP 7.4 through PHP 8.x, and Linux x86_64/aarch64.

## Install or upgrade

1. Extract the release ZIP and run `sudo ./recuploader/install.sh`.
2. The installer creates a mandatory backup before its first mutation. It aborts if the backup cannot be completed or verified.
3. Open **Admin > Seda Sanj > Import Configuration**.
4. Upload `sedasanj-freepbx-config.json`, review the masked preview, and apply it.
5. Place inbound and outbound canary calls and monitor the queue, disk space, and ingest status.

## Installation backup and restore

Every CLI or `fwconsole` installation creates a timestamped, root-only backup under `/var/backups/sedasanj-recuploader/`. The backup includes the existing module, the verified `callrecording` core file, managed Asterisk dialplan files, systemd and sudoers files, uploader binaries, configuration, state, queue, and logs. It also contains a manifest, present/absent path lists, and SHA-256 checksums.

To create the same backup manually before uploading or extracting a new release:

```bash
sudo ./recuploader/backup-installation.sh
```

Keep the printed backup directory. To verify it:

```bash
sudo sh -c 'cd /var/backups/sedasanj-recuploader/BACKUP_DIRECTORY && sha256sum -c SHA256SUMS'
```

To restore the exact pre-installation state, use the restore helper from the extracted release:

```bash
sudo ./recuploader/restore-installation-backup.sh /var/backups/sedasanj-recuploader/BACKUP_DIRECTORY
```

The restore helper verifies every checksum, rejects paths outside the fixed managed-path allowlist, stops the uploader, restores files and permissions, reloads FreePBX, and returns the service to its previous active/stopped state. Copy the backup off the PBX before production installation if the host itself is not covered by another backup system.

Upgrades from older module releases are supported when `callrecording/functions.inc.php` is already patched but the new rollback state is absent. The installer accepts that state only when a legacy `.orig` or state-directory backup reproduces the installed patched file exactly; it then imports the verified original into the new checksum-protected rollback state. Any mismatch aborts before installation changes.

The installer sets executable permissions on all bundled encoder directories, including GSM, in both the FreePBX module tree and the deployed runtime tree. Import validation also repairs a missing executable bit when permitted and checks the deployed runtime encoder as a fallback.

SQLite persistence uses legacy-compatible `INSERT OR IGNORE` plus `UPDATE` transactions rather than UPSERT syntax, so FreePBX distributions with older SQLite libraries can record state and queue jobs. Existing stereo recordings that stopped immediately after `Starting upload` remain in the monitor tree and are recovered by the first sweep after upgrade. Metadata for older inbound sidecars is completed from the stable FreePBX recording filename when destination or direction was not recorded.

Free-form configuration strings are stored in Base64 companion fields before PHP parses the INI file. This preserves regular-expression backslashes under `INI_SCANNER_RAW` and prevents parse-back mismatches. Installation verifies that the deployed runtime engine matches the module release before restarting the service.

The importer accepts only schema version 1 profiles targeted at `freepbx-module`. It validates the file, runtime, paths, regular expressions, binaries, API key, transport, and optional ZIP password before offering a ten-minute one-time apply token. Apply uses a parse-checked atomic configuration replacement and rolls back the KV store, file, and service when restart verification fails.

## Transport and local archive

`upload.format` controls the payload accepted by the API key: `gzip`, unencrypted `zip`, or AES-256 `zip` when `general.archive_password` is configured. `archive.format` is separate and controls only the local mono copy; its default is `gsm`.

HTTP 402 responses remain in `blocked_credit`, do not consume an attempt, and retry after `queue.credit_retry_seconds`. Pending and failed recordings are never removed by retention. Only successfully uploaded files in the configured `uploaded` directory are removed after `state.retention_days`.

## Uninstall

Run `sudo ./recuploader/uninstall.sh` to keep config, state, queue, and logs, or add `--purge` to remove them. Purge deletes pending and failed recordings and must only be used after a backup.
